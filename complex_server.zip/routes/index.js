
/*
 * GET home page.
 */

exports.index = function(req, res){
  res.render('index', { title: 'Express' });
};

exports.getdata = function(req, res){
  res.json({events: events});
};

exports.setdata = function(req, res){
  res.render('index', { title: 'Express' });
};

var events = [ { "Date": "Jun 17", "Host": "Jael Watts", "Location": "P.O. Box 380, 4326 Pretium Avenue", "Description": "ac turpis egestas. Aliquam fringilla cursus purus. Nullam scelerisque neque sed sem egestas blandit. Nam nulla magna, malesuada" }, { "Date": "Jun 25", "Host": "Quentin Russo", "Location": "7059 Ridiculus St.", "Description": "auctor non, feugiat nec, diam. Duis mi enim, condimentum eget, volutpat ornare, facilisis" }, { "Date": "Jun 14", "Host": "Vielka Cook", "Location": "P.O. Box 571, 3584 Nec Rd.", "Description": "enim diam vel arcu. Curabitur ut odio vel est tempor bibendum. Donec felis orci, adipiscing non, luctus" }, { "Date": "Jun 22", "Host": "Sybil Joyce", "Location": "3721 Curabitur St.", "Description": "sagittis felis. Donec tempor, est ac" }, { "Date": "Jun 06", "Host": "Farrah Curtis", "Location": "P.O. Box 695, 5123 Integer Ave", "Description": "eleifend nec, malesuada ut, sem. Nulla interdum. Curabitur dictum. Phasellus in felis. Nulla tempor augue ac ipsum. Phasellus vitae" }, { "Date": "Jun 25", "Host": "Malachi Ramsey", "Location": "P.O. Box 843, 3720 Pede St.", "Description": "vehicula. Pellentesque tincidunt tempus risus. Donec egestas. Duis ac arcu. Nunc" } ]